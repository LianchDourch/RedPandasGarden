#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "industryform.h"
#include <QMainWindow>
#include <QMdiArea>
#include <QMdiSubWindow>
#include "subapplications.h"
#include "util.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    inline static MainWindow* INSTANCE = nullptr;
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void initialize();
    void refreshMutableLists();

    void openApp(SubApplication* app);

    void onStationsListChange() {
        SubApplications::onStationsListChange();
    }

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;
private:
    Ui::MainWindow *ui;
    QMdiSubWindow* loadingScreen = nullptr;
};
#endif // MAINWINDOW_H
