#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "addstationform.h"
#include "characterconnexionform.h"
#include "loadingform.h"
#include "subapplications.h"
#include <qboxlayout.h>
#include <qpushbutton.h>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    INSTANCE = this;

    loadingScreen = ui->mdiArea_mainview->addSubWindow(new LoadingForm);
    loadingScreen->showMaximized();
}

void MainWindow::initialize() {
    setWindowTitle("Engineering Red Panda");
    Util::println("Initializing mainwindow");

    COLORED_TOP_BAR(45, 45, 45);

    QPushButton* button;
    for (SubApplication* app: SubApplications::APPLICATIONS) {
        app->setWindow(ui->mdiArea_mainview->addSubWindow(app->getWidgetProvider()(this)));
        app->getWindow()->setAttribute(Qt::WA_DeleteOnClose, false);
        app->getWindow()->installEventFilter(this);
        app->getWindow()->setWindowTitle(app->getName());
        app->getWindow()->hide();

        button = new QPushButton(app->getSmallName(), ui->widget_navbuttons);
        button->setMinimumHeight(40);
        ui->widget_navbuttons->layout()->addWidget(button);
        button->setFlat(true);
        connect(button, &QPushButton::clicked, this, [this, app] () { openApp(app); });
    }

    loadingScreen->deleteLater();
    loadingScreen = nullptr;

    refreshMutableLists();
}

void MainWindow::refreshMutableLists() {
    dynamic_cast<CharacterConnexionForm*>(SubApplications::CHARACTERS_MANAGER->getWindow()->widget())->refreshCharacters();
    dynamic_cast<AddStationForm*>(SubApplications::STATION_MANAGER->getWindow()->widget())->refreshCharacters();
    dynamic_cast<IndustryForm*>(SubApplications::MANUFACTURE_PLANNER->getWindow()->widget())->refreshMutableLists();
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::Close) {
        QMdiSubWindow *subWindow = qobject_cast<QMdiSubWindow*>(obj);
        if (subWindow) {
            subWindow->hide();
            event->ignore();
            return true;
        }
    }

    return QMainWindow::eventFilter(obj, event);
}

void MainWindow::openApp(SubApplication* app) {
    QMdiSubWindow *temp = ui->mdiArea_mainview->currentSubWindow();

    if (loadingScreen != nullptr) return;

    if (temp != nullptr && temp->isMaximized()) {
        app->getWindow()->showMaximized();
    } else {
        app->getWindow()->hide();
        app->getWindow()->show();
    }
}

MainWindow::~MainWindow()
{
    delete ui;
    INSTANCE = nullptr;
}
