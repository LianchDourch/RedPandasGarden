#include "esimanager.h"
#include <QNetworkRequest>
#include <QUrlQuery>
#include <QDesktopServices>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

void EsiManager::fetchSystemCostIndices(QSet<int> targetSystemId, std::function<void(const QMap<int, VariableCostIndices>&)> then, std::function<void (const QString &)> errorListener) {
    QUrl url("https://esi.evetech.net/latest/industry/systems/");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::UserAgentHeader, "Engineering Red Panda");

    QNetworkReply* reply = networkManager.get(request);

    connect(reply, &QNetworkReply::finished, [reply, targetSystemId, then]() {
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            Util::error("Erreur ESI : " + reply->errorString());
            return;
        }

        QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        if (!doc.isArray()) return;

        QJsonArray systemsArray = doc.array();

        QMap<int, VariableCostIndices> res = {};
        for (QJsonValueRef sysValue : systemsArray) {
            VariableCostIndices resultIndices;
            QJsonObject sysObj = sysValue.toObject();
            if (targetSystemId.contains(sysObj["solar_system_id"].toInt())) {

                QJsonArray indices = sysObj["cost_indices"].toArray();

                for (QJsonValueRef indValue : indices) {
                    QJsonObject indObj = indValue.toObject();
                    QString activity = indObj["activity"].toString();
                    double indexValue = indObj["cost_index"].toDouble();

                    if (activity == "manufacturing") resultIndices.set(0, indexValue);
                    else if (activity == "researching_time_efficiency") resultIndices.set(1, indexValue);
                    else if (activity == "researching_material_efficiency") resultIndices.set(2, indexValue);
                    else if (activity == "copying") resultIndices.set(3, indexValue);
                    else if (activity == "invention") resultIndices.set(4, indexValue);
                    else if (activity == "reactions") resultIndices.set(5, indexValue);

                }
                res.insert(sysObj["solar_system_id"].toInt(), resultIndices);
                if (res.size() == targetSystemId.size()) break;
            }
        }

        then(res);
    });
}

void EsiManager::fetchAdjustedPrices(Then then, ERROR_LISTENER_CPP) {
    requestERP("DELETE FROM adjustedPrices");

    QNetworkRequest req = QNetworkRequest(QUrl("https://esi.evetech.net/latest/markets/prices/?datasource=tranquility"));

    req.setHeader(QNetworkRequest::UserAgentHeader, "Engineering Red Panda");

    QNetworkReply* reply = networkManager.get(req);
    connect(reply, &QNetworkReply::finished, [reply, then, errorListener] () {
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            errorListener(reply->errorString());
            then();
            return;
        }

        QByteArray rawData = reply->readAll();

        QJsonParseError parseError;
        QJsonDocument doc = QJsonDocument::fromJson(rawData, &parseError);

        if (parseError.error != QJsonParseError::NoError) {
            errorListener("Erreur de parsing JSON: " + parseError.errorString());
            then();
            return;
        }

        if (!doc.isArray()) {
            errorListener("Format de réponse ESI invalide (Tableau attendu).");
            then();
            return;
        }

        QJsonArray priceArray = doc.array();


        ERP.transaction();

        for (const QJsonValue &value : priceArray) {
            QJsonObject obj = value.toObject();
            int typeId = obj["type_id"].toInt();
            double adjustedPrice, averagePrice;

            if (obj.contains("adjusted_price")) {
                adjustedPrice = obj["adjusted_price"].toDouble();
            } else {
                adjustedPrice = 0.0;
            }

            if (obj.contains("average_price")) {
                averagePrice = obj["average_price"].toDouble();
            } else {
                averagePrice = 0.0;
            }

            requestERP("INSERT INTO adjustedprices VALUES (:typeId, :adjustedPrice, :averagePrice)", {
                    {"typeId", typeId},
                    {"adjustedPrice", adjustedPrice},
                    {"averagePrice", averagePrice},
            });
        }

        ERP.commit();

        then();
    });
}

double EsiManager::getAdjustedPrice(qint64 itemId, bool refreshPrices) {
    bool ok = false;
    double price = -1.0;

    {
        QSqlQuery query = requestERP(
            "SELECT adjustedPrice FROM adjustedPrices WHERE typeId = :typeId",
            {{"typeId", itemId}}, &ok);

        if (query.next() && ok) {
            price = query.value("adjustedPrice").toDouble();
        }
    }

    return price;
}

double EsiManager::getEstimatedPrice(qint64 itemId, bool refreshPrices) {
    bool ok = false;
    double price = -1.0;

    {
        QSqlQuery query = requestERP(
            "SELECT averagePrice FROM adjustedPrices WHERE typeId = :typeId",
            {{"typeId", itemId}}, &ok);

        if (query.next() && ok) {
            price = query.value("averagePrice").toDouble();
        }
    }

    return price;
}

void EsiManager::requestIcon(int typeId, int size, std::function<void(const QPixmap&)> receiver, std::function<void(const QString&)> error, QString terminaison) {
    // Construction de l'URL officielle de CCP
    QString urlStr = QString("https://images.evetech.net/types/%1/%3?size=%2")
                         .arg(typeId)
                         .arg(size)
                         .arg(terminaison);

    QUrl url(urlStr);
    QNetworkRequest request(url);

    // Lancement de la requête asynchrone
    QNetworkReply* reply = networkManager.get(request);

    // Connexion moderne Qt6 avec une fonction lambda pour traiter le résultat
    connect(reply, &QNetworkReply::finished, [reply, receiver, error]() {
        reply->deleteLater(); // Nettoyage de la mémoire de la requête

        if (reply->error() != QNetworkReply::NoError) {
            error("Unable to download icon :" + reply->errorString());
            return;
        }

        // Lecture des données brutes reçues
        QByteArray data = reply->readAll();
        QPixmap pixmap;

        if (pixmap.loadFromData(data)) {
            receiver(pixmap);
        } else {
            error("Unable to convert raw datas to an image.");
        }
    });
}

QSqlQuery EsiManager::request(QSqlDatabase* base, const QString &req, const QMap<QString, QVariant>& values, bool* ok, const std::function<void(QSqlError error)> onError) {
    QSqlQuery query(*base);
    query.prepare(req);
    for (auto [k, v] : values.asKeyValueRange()) {
        query.bindValue(":" + k, v);
    }

    if (!query.exec()) {
        std::cerr << "[" << base->connectionName().toStdString() << "] " << "Erreur SQL : '" << query.lastError().text().toStdString() << "' while executing : " << req.toStdString() << std::endl;
        if (ok != nullptr) *ok = false;
        return QSqlQuery();
    }

    if (ok != nullptr) *ok = true;
    return query;
}

QSqlQuery EsiManager::requestERP(const QString &req, const QMap<QString, QVariant>& values, bool* ok, const std::function<void(QSqlError error)> onError) {
    return request(&ERP, req, values, ok, onError);
}

void EsiManager::fetchFreeports(Then then, ERROR_LISTENER_CPP) {
    QUrl url("https://esi.evetech.net/latest/universe/structures/?datasource=tranquility");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::UserAgentHeader, "EngineeringRedPanda");

    QNetworkReply *reply = networkManager.get(request);

    connect(reply, &QNetworkReply::finished, [reply, errorListener, then]() {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            return errorListener(reply->errorString());
        }

        QJsonDocument doc = QJsonDocument::fromJson(reply->readAll());
        if (doc.isArray()) {
            resolveFreeportNamesInBatches(doc.array(), then, errorListener);
        }
    });
}

void EsiManager::resolveFreeportNamesInBatches(const QJsonArray& allIds, Then then, ERROR_LISTENER_CPP) {
    int i = 0;
    while (i < allIds.size()) {
        QJsonArray batch;
        for (int j = 0; j < 1000 && i < allIds.size(); ++j, ++i) {
            batch.append(allIds[i]);
        }

        sendFreeportBatchRequest(batch, then, errorListener);
    }
}

void EsiManager::sendFreeportBatchRequest(const QJsonArray& batchIds, Then then, ERROR_LISTENER_CPP) {
    QUrl url("https://esi.evetech.net/latest/universe/names/?datasource=tranquility");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setHeader(QNetworkRequest::UserAgentHeader, "EngineeringRedPanda");

    //QJsonDocument doc(batchIds);
    QJsonDocument doc(QJsonArray({QJsonValue(1050444740652ll)}));
    QNetworkReply *reply = networkManager.post(request, doc.toJson(QJsonDocument::Compact));

    connect(reply, &QNetworkReply::finished, [reply, then, errorListener]() {
        struct Datas {
            qint64 structureId;
            QString name;
        };

        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) return errorListener("=( " + reply->errorString());

        qDebug() << reply->readAll();
        /*
        QJsonDocument resDoc = QJsonDocument::fromJson(reply->readAll());
        if (!resDoc.isArray()) return;

        QJsonArray results = resDoc.array();
        for (const QJsonValue& val : results) {
            QJsonObject obj = val.toObject();
            // L'ESI renvoie la catégorie pour être sûr que c'est une structure
            if (obj["category"].toString() == "structure") {
                Datas data;
                data.stationId = obj["id"].toVariant().toLongLong();
                data.stationName = obj["name"].toString();
                resolvedFreeports.append(data);
            }
        }*/
    });
}
/*
void EsiManager::parseAndStore(const QByteArray& jsonData) {

    qDebug() << jsonData;

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    if (!doc.isArray()) {
        Util::error("Invalid JSON Format while parsing structures");
        return;
    }

    QJsonArray structuresArray = doc.array();

    EsiManager::requestERP("DELETE FROM structures");
    ERP.transaction();

    bool ok = true;

    for (const QJsonValue& value : structuresArray) {
        QJsonObject obj = value.toObject();

        Datas data;
        data.structureId = obj["structureID"].toString().toLongLong();
        data.name = obj["name"].toString();
        data.solarSystemId = obj["solarSystemID"].toInt();
        data.typeId = obj["typeID"].toInt();

        if (data.structureId > 0 && !data.name.isEmpty()) {
            bool temp;
            EsiManager::requestERP(
                "INSERT INTO structures VALUES (:stationId, :stationName, :systemId, :typeId)",
                {{"stationId", data.structureId}, {"stationName", data.name},
                 {"systemId", data.solarSystemId}, {"typeId", data.typeId}}, &temp);
            ok &= temp;

        }
    }

    ERP.commit();

    if (ok) Util::println("[INFO] : freeports récupérés avec succès.");
    else Util::println("[WARNING] : An error occured while fetching freeports");
}*/

QSqlQuery EsiManager::requestSDE(const QString &req, const QMap<QString, QVariant>& values, bool* ok, const std::function<void(QSqlError error)> onError) {
    return request(&SDE, req, values, ok, onError);
}

bool EsiManager::isBlueprint(const QString& itemName) {
    bool ok = false;
    int id = requestTypeId(itemName, &ok);
    if (!ok) return false;

    return isBlueprint(id);
}

bool EsiManager::isBlueprint(int typeId) {
    QSqlQuery res = EsiManager::requestSDE("SELECT 1 FROM industryBlueprints WHERE typeID = :typeId;", {{"typeId", typeId}});
    bool found = res.next();

    return found;
}


static constexpr auto AUTHORIZE_URL =
    "https://login.eveonline.com/v2/oauth/authorize";

static constexpr auto TOKEN_URL =
    "https://login.eveonline.com/v2/oauth/token";

static constexpr auto VERIFY_URL =
    "https://login.eveonline.com/oauth/verify";

static constexpr auto ESI_SKILLS_URL =
    "https://esi.evetech.net/latest/characters/%1/skills/";

static constexpr auto ESI_CHARACTER_URL =
    "https://esi.evetech.net/latest/characters/%1/";

EsiConnector::EsiConnector(QObject* parent)
    : QObject(parent)
{
    setupOAuth();
}

void EsiConnector::setupOAuth()
{
    m_replyHandler =
        new QOAuthHttpServerReplyHandler(
            12042,
            this);

    // Important pour EVE SSO
    m_replyHandler->setCallbackPath("/");

    m_oauth.setReplyHandler(m_replyHandler);

    m_oauth.setAuthorizationUrl(
        QUrl(AUTHORIZE_URL));

    // API moderne Qt6
    m_oauth.setTokenUrl(
        QUrl(TOKEN_URL));

    m_oauth.setClientIdentifier(
        m_clientId);

    m_oauth.setRequestedScopeTokens({
        "esi-skills.read_skills.v1",
        "esi-universe.read_structures.v1"
    });

    // PKCE moderne (recommandé par CCP)
    m_oauth.setPkceMethod(
        QOAuth2AuthorizationCodeFlow::PkceMethod::S256);

    connect(
        &m_oauth,
        &QOAuth2AuthorizationCodeFlow::authorizeWithBrowser,
        this,
        [](const QUrl& url)
        {
            QDesktopServices::openUrl(url);
        });

    connect(
        &m_oauth,
        &QOAuth2AuthorizationCodeFlow::granted,
        this,
        [this]()
        {
            fetchCharacterInfo();
        });

    // API moderne Qt6
    connect(
        &m_oauth,
        &QAbstractOAuth::requestFailed,
        this,
        [this](QAbstractOAuth::Error error)
        {
            emit loginFailed(
                QString("OAuth error: %1")
                    .arg(static_cast<int>(error)));
        });
}

void EsiConnector::login()
{
    m_oauth.grant();
}

void EsiConnector::logout()
{
    m_oauth.setToken({});
}

bool EsiConnector::isLoggedIn() const
{
    return !m_oauth.token().isEmpty();
}

QString EsiConnector::characterName() const
{
    return m_characterName;
}

qint64 EsiConnector::characterId() const
{
    return m_characterId;
}

void EsiConnector::fetchCharacterInfo()
{
    QNetworkRequest req = QNetworkRequest(QUrl(VERIFY_URL));

    req.setRawHeader(
        "Authorization",
        QString("Bearer %1")
            .arg(m_oauth.token())
            .toUtf8());

    auto* reply =
        m_network.get(req);

    connect(
        reply,
        &QNetworkReply::finished,
        this,
        [this, reply]()
        {
            const auto data =
                reply->readAll();

            reply->deleteLater();

            const auto doc =
                QJsonDocument::fromJson(data);

            if (!doc.isObject())
            {
                emit loginFailed(
                    "Invalid verify response");
                return;
            }

            const auto json =
                doc.object();

            m_characterName =
                json["CharacterName"]
                    .toString();

            m_characterId =
                json["CharacterID"]
                    .toInteger();

            emit loginSucceeded();
        });
}

void EsiConnector::fetchSkills()
{
    if (m_characterId == 0)
    {
        emit loginFailed(
            "Character ID not available");
        return;
    }

    const auto url =
        QUrl(
            QString(ESI_SKILLS_URL)
                .arg(m_characterId));

    QNetworkRequest req(url);

    req.setRawHeader(
        "Authorization",
        QString("Bearer %1")
            .arg(m_oauth.token())
            .toUtf8());

    auto* reply =
        m_network.get(req);

    connect(
        reply,
        &QNetworkReply::finished,
        this,
        [this, reply]()
        {
            const auto data =
                reply->readAll();

            reply->deleteLater();

            const auto doc =
                QJsonDocument::fromJson(data);

            if (!doc.isObject())
            {
                emit loginFailed(
                    "Invalid skills response");
                return;
            }

            emit skillsReceived(
                doc.object());
        });
}

void EsiConnector::fetchPlayerStation(qint64 structureId,
                                      std::function<void(const PlayerStation&)> receiver,
                                      ERROR_LISTENER)
{
    if (accessToken().isEmpty()) {
        errorListener("Token d'accès vide. Un joueur doit être connecté.");
        return;
    }

    QString urlStr = QString("https://esi.evetech.net/latest/universe/structures/%1/?datasource=tranquility")
                         .arg(structureId);

    QNetworkRequest request((QUrl(urlStr)));
    request.setHeader(QNetworkRequest::UserAgentHeader, "Engineering Red Panda");
    request.setRawHeader("Authorization", QString("Bearer %1").arg(accessToken()).toUtf8());

    QNetworkReply* reply = m_network.get(request);

    connect(reply, &QNetworkReply::finished, [reply, structureId, receiver, errorListener]() {
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            errorListener(QString("Erreur ESI Structure %1 : %2")
                              .arg(structureId)
                              .arg(reply->errorString()));
            return;
        }

        QByteArray data = reply->readAll();
        QJsonParseError parseError;
        QJsonDocument doc = QJsonDocument::fromJson(data, &parseError);

        if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
            errorListener("Erreur de parsing JSON ou format invalide pour la structure.");
            return;
        }

        QJsonObject obj = doc.object();
        PlayerStation station;
        station.structureId = structureId;
        station.name = obj["name"].toString();
        station.solarSystemId = obj["solar_system_id"].toInt();
        station.typeId = obj["type_id"].toInt(); // L'ESI renvoie aussi le type d'Athanor/Keepstar/etc.

        receiver(station);
    });
}
