#ifndef ESIMANAGER_H
#define ESIMANAGER_H

#include <QSqlQuery>
#include <QSqlError>
#include <QObject>
#include <QString>
#include <QStringList>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QOAuthHttpServerReplyHandler>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMap>
#include <functional>
#include <QOAuth2AuthorizationCodeFlow>
#include <QNetworkAccessManager>
#include <QHttpServer>
#include <QTcpServer>
#include "util.h"
#include "core.h"

#define ERP_CONNECTION_NAME "ERP_Static_Conn"
#define SDE_CONNECTION_NAME "SDE_Static_Conn"

class EsiManager : public QObject {
    Q_OBJECT
public:
    inline static QSqlDatabase SDE = QSqlDatabase();
    inline static QNetworkAccessManager networkManager = QNetworkAccessManager();
    inline static QSqlDatabase ERP = QSqlDatabase();
    inline static QMap<int, double> ADJUSTED_PRICES = {};

    static void initialize() {
        //! SDE
        SDE = QSqlDatabase::addDatabase("QSQLITE", SDE_CONNECTION_NAME);

        SDE.setDatabaseName("Datas/eve.db");

        if (!SDE.open()) {
            Util::println("[ERROR] : SDE not connected.");
        } else {
            Util::println("[INFO] : SDE connected.");
        }

        if (QSqlDatabase::contains(ERP_CONNECTION_NAME)) {
            Util::error("The connection already exists: " + QString(ERP_CONNECTION_NAME));
        } else {
            ERP = QSqlDatabase::addDatabase("QSQLITE", ERP_CONNECTION_NAME);
            ERP.setDatabaseName("Datas/erp.db");
            ERP.setConnectOptions("QSQLITE_BUSY_TIMEOUT=500");

            if (!ERP.open()) {
                Util::error("ERP DB not connected");
            } else {
                Util::println("[INFO] : ERP DB connected");
            }
        }
    }

    static void load(Then then) {
        fetchAdjustedPrices(then);
    }

    static bool isBlueprint(const QString& itemName);
    static bool isBlueprint(int typeId);

    static int requestTypeId(const QString& itemName, bool *ok = nullptr, std::function<void(QSqlError)> error = [] (QSqlError err) { Util::error(err.text()); }) {
        QSqlQuery work = requestSDE("SELECT typeID FROM invtypes WHERE typeName = :name", {{"name", itemName}}, ok, error);

        if (work.next()) {
            if (ok != nullptr) *ok = true;
            return work.value("typeID").toInt();
        }

        if (ok != nullptr) *ok = false;
        Util::error("Unable to gather typeId for " + itemName);
        return 0;
    }

    static QSqlQuery request(QSqlDatabase* base, const QString &req, const QMap<QString, QVariant>& values = {}, bool* ok = nullptr, const std::function<void(QSqlError error)> onError = [] (QSqlError error) { Util::println("[ERROR] : ", error.text()); });
    static QSqlQuery requestSDE(const QString &req, const QMap<QString, QVariant>& values = {}, bool* ok = nullptr, const std::function<void(QSqlError error)> onError = [] (QSqlError error) { Util::println("[ERROR] : ", error.text()); });
    static QSqlQuery requestERP(const QString &req, const QMap<QString, QVariant>& values = {}, bool* ok = nullptr, const std::function<void(QSqlError error)> onError = [] (QSqlError error) { Util::println("[ERROR] : ", error.text()); });

    static void requestIcon(int typeId, int size, std::function<void(const QPixmap&)> receiver, ERROR_LISTENER, QString terminaison = "icon");

    static void fetchSystemCostIndices(QSet<int> targetSystemId, std::function<void (const QMap<int, VariableCostIndices> &)> then, ERROR_LISTENER);

    static void fetchAdjustedPrices(Then receiver, ERROR_LISTENER);
    static void fetchFreeports(Then then, ERROR_LISTENER);
    static double getAdjustedPrice(qint64 itemId, bool refreshIfPossible = false);
    static double getEstimatedPrice(qint64 itemId, bool refreshIfPossible = false);
    static void fetchRegionalOrders(int typeId, int regionId, std::function<void(const QByteArray&)> callback, int page = 1) {
        auto allData = std::make_shared<QByteArray>("[");
        fetchPage(typeId, regionId, page, allData, callback);
    }

    /**
     * @brief parseMarketOrders
     * @param jsonData
     * @param targetStationId
     * @return {sellOrders, buyOrders}
     */
    static QPair<std::vector<MarketOrder>, std::vector<MarketOrder>> parseMarketOrders(const QByteArray& jsonData, long long targetStationId) {
        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
        if (!doc.isArray()) return {{}, {}};

        QJsonArray ordersArray = doc.array();

        std::vector<MarketOrder> sellOrders;
        std::vector<MarketOrder> buyOrders;

        for (const QJsonValue& value : ordersArray) {
            QJsonObject orderObj = value.toObject();

            if (orderObj["location_id"].toVariant().toLongLong() == targetStationId) {

                MarketOrder order {
                    orderObj["order_id"].toVariant().toLongLong(),
                    orderObj["price"].toDouble(),
                    orderObj["volume_remain"].toInt(),
                    orderObj["is_buy_order"].toBool()
                };

                if (order.isBuy) {
                    buyOrders.push_back(order);
                } else {
                    sellOrders.push_back(order);
                }
            }
        }

        std::sort(sellOrders.begin(), sellOrders.end(), [](const MarketOrder& a, const MarketOrder& b) {
            return a.price < b.price;
        });

        std::sort(buyOrders.begin(), buyOrders.end(), [](const MarketOrder& a, const MarketOrder& b) {
            return a.price > b.price;
        });

        return {sellOrders, buyOrders};
    }

    static QString characterPortraitUrl(qint64 characterId, int size)
    {
        return QString(
                   "https://images.evetech.net/characters/%1/portrait?size=%2")
            .arg(characterId)
            .arg(size);
    }

    static void fetchPlayerProtrait(qint64 playerId, int size, std::function<void(QPixmap)> receiver) {
        QNetworkRequest req(
            QUrl(characterPortraitUrl(playerId, size)));

        auto* reply =
            networkManager.get(req);

        QObject::connect(reply,
                &QNetworkReply::finished,
                [reply, receiver]()
                {
                    QPixmap pix;

                    pix.loadFromData(
                        reply->readAll());

                    receiver(std::move(pix));

                    reply->deleteLater();
                });
    }
private:
    static void resolveFreeportNamesInBatches(const QJsonArray& allIds, Then then, ERROR_LISTENER);
    static void parseAndStoreFreeports(const QByteArray& jsonData);
    static void sendFreeportBatchRequest(const QJsonArray& batchIds, Then then, ERROR_LISTENER);

    static void fetchPage(int typeId, int regionId, int page,
                   std::shared_ptr<QByteArray> accumulatedData,
                   std::function<void(const QByteArray&)> callback)
    {
        QString urlStr = QString("https://esi.evetech.net/latest/markets/%1/orders/"
                                 "?datasource=tranquility&order_type=all&type_id=%2&page=%3")
                             .arg(regionId).arg(typeId).arg(page);

        QNetworkRequest request((QUrl(urlStr)));
        QNetworkReply* reply = networkManager.get(request);

        connect(reply, &QNetworkReply::finished, [=]() {
            reply->deleteLater();

            if (reply->error() != QNetworkReply::NoError) {
                qWarning() << "Erreur ESI page" << page << ":" << reply->errorString();
                callback(QByteArray()); // Renvoie un tableau vide en cas d'erreur
                return;
            }

            QByteArray pageData = reply->readAll();

            if (pageData.startsWith('[')) {
                pageData.remove(0, 1);
            }
            if (pageData.endsWith(']')) {
                pageData.chop(1);
            }

            if (accumulatedData->size() > 1 && !pageData.isEmpty()) {
                accumulatedData->append(",");
            }
            accumulatedData->append(pageData);

            int totalPages = 1;

            if (reply->hasRawHeader("X-Pages")) {
                totalPages = reply->rawHeader("X-Pages").toInt();
            }

            if (page < totalPages) {
                fetchPage(typeId, regionId, page + 1, accumulatedData, callback);
            } else {
                accumulatedData->append("]");
                callback(*accumulatedData);
            }
        });
    }
};

struct PlayerStation {
    qint64 structureId = 0;
    QString name;
    int solarSystemId = 0;
    int typeId = 0;
};

class EsiConnector : public QObject
{
    Q_OBJECT

public:
    explicit EsiConnector(QObject* parent = nullptr);
    ~EsiConnector() {
        Util::println("Destructing EsiConnector");
    }

    void login();
    void logout();

    bool isLoggedIn() const;

    QString characterName() const;
    qint64 characterId() const;

    QString accessToken() const { return m_oauth.token(); }

    void fetchSkills();
    void fetchPlayerStation(qint64 structureId,
                                   std::function<void(const PlayerStation&)> receiver,
                                   std::function<void(const QString&)> errorListener);
signals:
    void loginSucceeded();
    void loginFailed(QString reason);

    void skillsReceived(QJsonObject skills);

private:
    void setupOAuth();
    void fetchCharacterInfo();

private:
    QOAuth2AuthorizationCodeFlow m_oauth;
    QOAuthHttpServerReplyHandler* m_replyHandler = nullptr;

    QNetworkAccessManager m_network;

    QString m_characterName;
    qint64 m_characterId = 0;

    QString m_clientId = "c8c02509619845b896226aefe267db22";
};


#endif // EVEMARKETFETCHER_H
